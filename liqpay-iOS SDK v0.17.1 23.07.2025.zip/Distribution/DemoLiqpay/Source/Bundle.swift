//
//  Bundle.swift
//  Liqpay app
//
//  Created by Aleksandr Gurin on 16/02/2024.
//  Copyright © 2024 PrivatBank. All rights reserved.
//

import Foundation


extension Bundle {
    
    var appVersion: String {
        let appName = (infoDictionary?["CFBundleName"] as? String) ?? ""
        return "\(appName) v\(releaseVersion) (\(buildVersion))"
    }
    
    var releaseVersion: String {
        return infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
    }
    var buildVersion: String {
        return infoDictionary?["CFBundleVersion"] as? String ?? ""
    }
    
}
