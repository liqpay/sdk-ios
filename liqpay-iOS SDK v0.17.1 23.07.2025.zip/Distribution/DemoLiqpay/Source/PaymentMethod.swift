//
//  PaymentMethod.swift
//  DemoLiqpay
//
//  Created by Aleksandr Gurin on 13.05.2025.
//

enum PaymentMethod: Int, CaseIterable {
    case privatPay
    case cardPay
    case tokenPay
    case applePay
    
    init(index: Int) {
        self = PaymentMethod(rawValue: index) ?? .cardPay
    }
}
