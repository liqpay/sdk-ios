//
//  ViewController.swift
//  PPayButton
//
//  Created by Ihor Malovanyi on 03.03.2020.
//  Copyright © 2020 Ihor Malovanyi. All rights reserved.
//

import UIKit
import liqpay_ios

class PrivatPayButtonPlayGround: UIViewController {

    @IBOutlet weak var privatPayButton: PrivatPayButton! {
        didSet {
            privatPayButton.buyWithStyle = true
            privatPayButton.whiteStyle = true
            ///0: English
            ///1: Russian
            ///2: Ukranian
            privatPayButton.localeCode = 2
            recomendedSizeLabel?.text = "\(privatPayButton.recommendedSize)"
        }
    }
    @IBOutlet weak var buyWithSwitcher: UISwitch!
    @IBOutlet weak var whiteSwitcher: UISwitch!
    @IBOutlet weak var urkLocaleSwitcher: UISwitch!
    @IBOutlet weak var recomendedSizeLabel: UILabel! {
        didSet {
            recomendedSizeLabel.text = "\(String(describing: privatPayButton?.recommendedSize))"
        }
    }
    @IBOutlet weak var blackImage: UIImageView!
    @IBOutlet weak var whiteOutlineImage: UIImageView!
    @IBOutlet weak var transparentImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buyWithSwitcher.isOn = privatPayButton.buyWithStyle
        whiteSwitcher.isOn = privatPayButton.whiteStyle
        urkLocaleSwitcher.isOn = privatPayButton.locale == .uk
        recomendedSizeLabel.text = "\(privatPayButton.recommendedSize)"
        
        blackImage.image        = PrivatPayMark.black
        whiteOutlineImage.image = PrivatPayMark.whiteWithOutline
        transparentImage.image  = PrivatPayMark.transparent
    }

    @IBAction func buyWith(_ sender: UISwitch) {
        privatPayButton.buyWithStyle = sender.isOn
        recomendedSizeLabel.text = "\(privatPayButton.recommendedSize)"
    }
    
    @IBAction func white(_ sender: UISwitch) {
        privatPayButton.whiteStyle = sender.isOn
        recomendedSizeLabel.text = "\(privatPayButton.recommendedSize)"
    }
    
    @IBAction func ukrLocale(_ sender: UISwitch) {
        privatPayButton.localeCode = sender.isOn ? 2 : 0
        recomendedSizeLabel.text = "\(privatPayButton.recommendedSize)"
    }

}

