//
//  ViewController.swift
//  TestLiqpay
//
//  Created by Aleksandr Gurin on 11.01.2021.
//  Copyright © 2021 PrivatBank. All rights reserved.
//

import UIKit
import Foundation
import liqpay_ios
import SafariServices

private struct LocalizedText {
    
    // MARK: - Localizations
    static var payOk: String { return "Оплата пройшла успішно".localized(fromTable: LiqpayLocalization.tableName) }
    static var userCancel: String { return "Скасовано користувачем".localized(fromTable: LiqpayLocalization.tableName) }
    static var selectMethod: String { return "Потрібно вибрати метод оплати!".localized(fromTable: LiqpayLocalization.tableName) }
    static var selectData: String { return "Необхідно ввести data і signature!".localized(fromTable: LiqpayLocalization.tableName) }
    static let processingClosed = "Закрито під час обробки. Платіж ще в дорозі!".localized(fromTable: LiqpayLocalization.tableName)
    static let userLinked = "Користувач уже залінкований".localized(fromTable: LiqpayLocalization.tableName)
    static let userLinkedOk = "Користувача успішно залінковано".localized(fromTable: LiqpayLocalization.tableName)
    static let userNotLinked = "Користувача незалінковано".localized(fromTable: LiqpayLocalization.tableName)
    static let cardAdded = "Картку додано: ".localized(fromTable: LiqpayLocalization.tableName)
    static let userCancelAddCard = "Користувач скасував додання картки".localized(fromTable: LiqpayLocalization.tableName)
    static let closeWallet = "Користувач закрив гаманець".localized(fromTable: LiqpayLocalization.tableName)
    static let deleteCardOk = "Картку успішно видалено".localized(fromTable: LiqpayLocalization.tableName)
    static let unknowError = "Невідома помилка".localized(fromTable: LiqpayLocalization.tableName)
    static let userCancelLink = "Користувач скасував лінкування".localized(fromTable: LiqpayLocalization.tableName)

}

final class ViewController: UIViewController {

    // MARK: - IBOutlet
    @IBOutlet private weak var scrollView: UIScrollView!
        
    @IBOutlet weak var isUk: UISwitch!
    
    @IBOutlet weak var liqSw: UISwitch!
    @IBOutlet weak var liqDataTF: UITextField!
    @IBOutlet weak var liqSignatureTF: UITextField!
    
    @IBOutlet weak var cardSw: UISwitch!
    @IBOutlet weak var cardDataTF: UITextField!
    @IBOutlet weak var cardSignatureTF: UITextField!
    
    @IBOutlet weak var tokenSw: UISwitch!
    @IBOutlet weak var tokenDataTF: UITextField!
    @IBOutlet weak var tokenSignatureTF: UITextField!
    
    @IBOutlet weak var appleSw: UISwitch!
    @IBOutlet weak var appleDataTF: UITextField!
    @IBOutlet weak var appleSignatureTF: UITextField!
    
    @IBOutlet weak var merchantIDButton: UIButton! {
        didSet {
            merchantIDButton.setTitle("\(merchantIDTest)", for: .normal)
        }
    }
    
    @IBOutlet weak var payButton: UIButton!
    
    @IBOutlet weak var countryCodeTF: UITextField!
    @IBOutlet weak var phoneNumberTF: UITextField!
    
    @IBOutlet weak var languageLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var version: UILabel!
    
    // MARK: - Vars
    // Customer merchant id for Apple Pay
    var merchantIDTest = "merchant.liqpay.applepay" {
        didSet {
            merchantIDButton.setTitle("\(merchantIDTest)", for: .normal)
        }
    }
    // Deeplink
    var appRedirectURLTest = "demoliqpay://home"
    // Docs
    let liqpayTestDataURL = URL(string: "https://www.liqpay.ua/documentation/forming_test_data/")!
    // Client Phone
    let countryCode = "380"
    let phoneNumber = "123456789"
    
    var payment: LiqPayPayment?
    
    var switchers: [UISwitch]       {[liqSw,           cardSw,             tokenSw,             appleSw             ]}
    var dataTFs: [UITextField]      {[liqDataTF,       cardDataTF,         tokenDataTF,         appleDataTF         ]}
    var signatureTFs: [UITextField] {[liqSignatureTF,  cardSignatureTF,    tokenSignatureTF,    appleSignatureTF    ]}
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        }
        navigationItem.title = "Test"
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
        
        var i = 0
        switchers.forEach { sw in
            sw.tag = i
            dataTFs[i].delegate = self
            signatureTFs[i].delegate = self
            
            i+=1
        }
        
        onSelectPay(cardSw)
        registerNotifications()
        
        countryCodeTF.text = countryCode
        phoneNumberTF.text = phoneNumber
        languageLabel.text = "Язык системы: \(Locale.current.languageCode ?? "en")"
        version.text = Bundle.main.appVersion + " (Prod)"

        // Для тестирования можно использовать данные ниже, возможно что они со временем прокиснут
        // карта 4000000000009995 с любым сроком действия и свв всегда вернет ошибку
        // карта 4731185600070103 с любым сроком действия и свв всегда пройдет оплата
        
        
        if LiqPayPayment.canOpenPrivat24App() {
            // *** PrivatPay ***
            liqDataTF.text = "eyJvcmRlcl9pZCI6InF3ZWZmZjIxIiwiYW1vdW50IjoiMC4xIiwiY3VycmVuY3kiOiJVQUgiLCJjdXN0b21lciI6IjM4MDY3NTEyNTg3MyIsImN1c3RvbWVyX3VzZXJfaWQiOjY3NTEyNTg3MywiZGVzY3JpcHRpb24iOiJ0ZXN0U0RLIiwicGF5dHlwZSI6Im1wb25lY2xpY2siLCJwdWJsaWNfa2V5IjoiaTgyNjMwNjg4OTIxIiwidmVyc2lvbiI6M30="
            liqSignatureTF.text = "iQbc4uF+WlhnjZ0eFWAM6XWuE/g="
        } else {
            liqDataTF.text = "Не доступно приложение Privat24"
            liqSignatureTF.text = "Не доступно приложение Privat24"
        }
        
        // *** CardPay ***
        // ввести карту для оплаты 4242424242424242 с любым сроком и цвв
        cardDataTF.text = "eyJ2ZXJzaW9uIjozLCJhY3Rpb24iOiJwYXkiLCJhbW91bnQiOiIwLjM1IiwiY3VycmVuY3kiOiJVQUgiLCJkZXNjcmlwdGlvbiI6ItCc0ZbQuSDRgtC+0LLQsNGAIiwicHVibGljX2tleSI6Imk4NDM4ODM2Mzc3NSIsImxhbmd1YWdlIjoidWsifQ=="
        cardSignatureTF.text = "0bKJ1IscWGBmki/NM/qpsBju4C4="

        // *** TokenPay ***
        tokenDataTF.text = "eyJ2ZXJzaW9uIjozLCJhY3Rpb24iOiJwYXkiLCJhbW91bnQiOiIwLjIxIiwiY3VycmVuY3kiOiJVQUgiLCJkZXNjcmlwdGlvbiI6Ik9UUCIsInB1YmxpY19rZXkiOiJpODIxNDA2NDY5OTUiLCJsYW5ndWFnZSI6InVrIn0="
        tokenSignatureTF.text = "q11InxGptW801/IggvqEaHXO0sw="
        
        if LiqPayPayment.canMakeApplePayPayments() {
            // *** ApplePay ***
            appleDataTF.text = "eyJ2ZXJzaW9uIjozLCJhY3Rpb24iOiJwYXkiLCJhbW91bnQiOiIwLjM1IiwiY3VycmVuY3kiOiJVQUgiLCJkZXNjcmlwdGlvbiI6ItCc0ZbQuSDRgtC+0LLQsNGAIiwicHVibGljX2tleSI6Imk4NDM4ODM2Mzc3NSIsImxhbmd1YWdlIjoidWsifQ=="
            appleSignatureTF.text = "0bKJ1IscWGBmki/NM/qpsBju4C4="
        } else {
            appleDataTF.text = "Не доступно ApplePay"
            appleSignatureTF.text = "Не доступно ApplePay"
            appleSw.isEnabled = false
        }
        
        DispatchQueue.delay(delay: 0.5) {
            self.preshowStatus()
        }
    }
    
    private func preshowStatus() {
        showStatus()
        DispatchQueue.delay(delay: 0.3) {
            self.scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
    }
    
    private func showStatus() {
        let bottomOffset = CGPoint(x: 0, y: scrollView.contentSize.height - scrollView.bounds.height + scrollView.contentInset.bottom)
        scrollView.setContentOffset(bottomOffset, animated: true)
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        scrollView.contentInset.bottom = 0
    }
    
    // MARK: - IBAction
    @IBAction func onSelectPay(_ sender: UISwitch) {
        UIView.animate(withDuration: 0.3) {
            self.switchers.forEach {
                let isOn = $0 == sender
                $0.isOn = isOn
            }
        }
    }
    
    @IBAction func onPay(_ sender: Any) {
        statusLabel.text = ""
        
        payButton.isEnabled = false
        
        if let selectedIndex = switchers.first(where: { $0.isOn })?.tag {
            
            let data = dataTFs[selectedIndex].text
            let signature = signatureTFs[selectedIndex].text
            
            if data == nil || data?.isEmpty == true || signature == nil || signature?.isEmpty == true {
                statusLabel.text = LocalizedText.selectData
                payButton.isEnabled = true
                return
            }
            
            initPayment(data: data, signature: signature)
            
            let method = PaymentMethod(index: selectedIndex)
            switch method {
            case .privatPay: sendTestPrivatPay()
            case .cardPay: sendTestCardPay()
            case .tokenPay: sendTestTokenPay()
            case .applePay: sendTestApplePay()
            }
            
        } else { statusLabel.text = LocalizedText.selectMethod }
        
    }
    
    @IBAction func generateNewDataSignature(_ sender: UIButton) {
        let safari = SFSafariViewController(url: liqpayTestDataURL)
        present(safari, animated: true)
    }
    
    @IBAction func enterMerchantID(_ sender: Any) {
        let alert = UIAlertController(title: "Enter Merchant ID",
                                      message: "Current: \(merchantIDTest)",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            self.merchantIDTest = alert.textFields?.first?.text ?? self.merchantIDTest
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        alert.addTextField { textField in
            textField.placeholder = self.merchantIDTest
        }
        present(alert, animated: true)
    }
    
    @IBAction func unwind(segue: UIStoryboardSegue) {
        // do not remove. its for close button PrivatPayButtonPlayGround
    }
    
}

// MARK: - Payments
extension ViewController {
    
    private func initPayment(data: String?, signature: String?) {
        payment = nil

        // presenterViewController - Контроллер, от которого будет показан UI Apple Pay и другие всплываеющие окна
        // В качестве передаваемого значения мы рекомендуем использовать rootViewController приложения

        payment = LiqPayPayment(data: data ?? "",
                                signature: signature ?? "",
                                applePayMerchantID: merchantIDTest,
                                appRedirectURL: appRedirectURLTest,
                                language: isUk.isOn == true ? "uk" : "en",        // or Locale.current.languageCode
                                presenterViewController: self,
                                delegate: self
        )
    }
    
    private func sendTestCardPay() {
        payment?.payCardPay(
            countryCode: countryCodeTF.text ?? countryCode,
            phoneNumber: phoneNumberTF.text ?? phoneNumber
        ) { [weak self] success, error in
            DispatchQueue.updateUI {
                self?.handleResult(success, error)
            }
        }
    }
    
    private func sendTestTokenPay() {
        payment?.payTokenPay(
            countryCode: countryCodeTF.text ?? countryCode,
            phoneNumber: phoneNumberTF.text ?? phoneNumber
        ) { [weak self] success, error in
            DispatchQueue.updateUI {
                self?.handleResult(success, error)
            }
        }
    }
    
    private func sendTestPrivatPay() {
        payment?.payPrivatPay { [weak self] success, error in
            DispatchQueue.updateUI {
                self?.handleResult(success, error)
            }
        }
        payButton.isEnabled = true
    }
    
    private func sendTestApplePay() {
        guard LiqPayPayment.canMakeApplePayPayments() else {
            statusLabel.text = "Apple Pay не доступно"
            return
        }
        
        payment?.payApplePay(
            completion: { [weak self] success, error in
                DispatchQueue.updateUI {
                    self?.handleResult(success, error)
                }
            },
            closedDuringProcessing: { [weak self] in
                DispatchQueue.updateUI {
                    // финальный статус платежа еще не известен (платеж в обработке)
                    self?.payButton.isEnabled = true
                    self?.statusLabel.text = LocalizedText.processingClosed
                }
            }
        )
    }
    
    private func showError(_ error: LiqPayError?) {
        let text = "Error code [\(error?.code.rawValue ?? -1)]\n\(error?.originErrorCode != nil ? "[\(String(describing: error?.originErrorCode))]\n" : "")description: \(error?.errorDescription ?? LocalizedText.unknowError)"
        statusLabel.text = text
        showStatus()
    }
    
    private func handleResult(_ success: Bool, _ error: LiqPayError?) {
        payButton.isEnabled = true
        
        if success {
            statusLabel.text = LocalizedText.payOk
        } else if let error = error {
            // не удалось совершить оплату
            
            // Примечание: Если получили код ошибки serverError или insufficientFunds, то необходимо запросить новую data и signature и создать новый объект LiqPayPayment. Иначе при попытке повторить запрос с той же data и signature сервер все равно откажет но уже c кодом ошибки 'duplicatedOrderId'.
            
            switch error.code {
                case .serverError: //серверная ошибка LiqPay
                break
                
                case .noInternetConnection: //нет интернет соединения
                break

                case .internalError: //внутренняя ошибка в логике работы framework
                break

                case .applePayCantMakePayments: //устройство не поддерживает Apple Pay платежи
                break

                case .applePayEmptyToken: //такая ошибка может быть только на симуляторе
                break
                
                default: break
            }
            showError(error)
        } else {
            statusLabel.text = "Unknown state,\noperation result not success and error is nil"
        }
        showStatus()
    }
    
}

extension ViewController: LiqPayPaymentDelegate {

    func liqPayPayment(_ payment: liqpay_ios.LiqPayPayment, didReceiveError error: liqpay_ios.LiqPayError) {
        DispatchQueue.updateUI {
            self.payButton.isEnabled = true
            self.showError(error)
        }
    }
    
}

extension ViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}

//MARK: - Handle keybord functions
extension ViewController {
    
    private func registerNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc private func keyboardWillShow(notification: NSNotification){
        guard let keyboardFrame = notification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
        let inset = view.convert(keyboardFrame.cgRectValue, from: nil).size.height
        scrollView.contentInset.bottom = inset
    }

    @objc private func keyboardWillHide(notification: NSNotification){
        scrollView.contentInset.bottom = 0
    }
    
    @objc private func hideKeyboard() {
        view.endEditing(true)
    }
    
}


