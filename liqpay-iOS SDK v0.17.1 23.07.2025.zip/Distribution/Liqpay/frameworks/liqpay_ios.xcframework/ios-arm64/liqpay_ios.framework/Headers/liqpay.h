//
//  liqpay.h
//  liqpay
//
//  Created by Maksym Letiushov on 10/10/18.
//  Copyright © 2018 PrivatBank. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for liqpay.
FOUNDATION_EXPORT double liqpayVersionNumber;

//! Project version string for liqpay.
FOUNDATION_EXPORT const unsigned char liqpayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <liqpay/PublicHeader.h>
